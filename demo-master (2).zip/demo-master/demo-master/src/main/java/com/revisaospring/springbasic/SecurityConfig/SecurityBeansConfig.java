package com.revisaospring.springbasic.SecurityConfig;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
// ela vai fazer a criptografar a senha para mandar para banco

//configurar o security  https://github.com/Gumorettis/arquivosAulaSpring

@Configuration
public class SecurityBeansConfig {

    @Bean
    public PasswordEncoder passwordEncorder(){
        return new BCryptPasswordEncoder();
    }
}
